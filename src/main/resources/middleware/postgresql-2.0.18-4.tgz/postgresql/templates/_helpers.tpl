{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "pgsql.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "pgsql.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "pgsql.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "pgsql.labels" -}}
helm.sh/chart: {{ include "pgsql.chart" . }}
{{ include "pgsql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pgsql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pgsql.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "pgsql.initdb" -}}
initdb:
{{- with .Values.patroni.initdb }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addInitdb" . | nindent 2 -}}
{{- end }}

{{- define "pgsql.addInitdb" -}}
{{- $pg9 := semverCompare "<10.0" .Values.pgsqlVersion }}
{{- if .Values.customVolumes -}}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pgwal" -}}
{{- if $pg9 }}
xlogdir: "{{- get . "mountPath" -}}"
{{- else }}
waldir: "{{- get . "mountPath" -}}"
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "pgsql.userPasswords" -}}
userPasswords:
{{- with .Values.userPasswords }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addStandby" . | nindent 2 -}}
{{- end }}

{{- define "pgsql.addStandby" -}}
{{- if not .Values.userPasswords.standby -}}
standby: Hc@Cloud01
{{- end }}
{{- end }}

{{- define "pgsql.version" -}}
{{- if eq (semverCompare "<10.0" .Values.pgsqlVersion) true }}
{{- .Values.pgsqlVersion | quote }}
{{- else }}
{{- substr 0 2 .Values.pgsqlVersion | quote}}
{{- end }}
{{- end }}

{{- define "pgsql.customEnvs" -}}
{{- if or .Values.customEnvs ((((.Values.logging).collection).stdout).enabled) ((((.Values.logging).collection).filelog).enabled) .Values.features.auditLog.enabled}}
customEnvs:
{{- with .Values.customEnvs }}
{{- toYaml . | nindent 2 -}}
{{- end }}
  {{- if ((((.Values.logging).collection).stdout).enabled)}}
  aliyun_logs_middlewarestdout: stdout
  aliyun_logs_middlewarestdout_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
{{- $logDir := "/home/postgres/pgdata/pgroot/pg_log" }}
{{- if .Values.customVolumes }}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pglog" }}
{{- $logDir = (get . "mountPath") }}
{{- end }}
{{- end }}
{{- end }}
  {{- if ((((.Values.logging).collection).filelog).enabled)}}
  aliyun_logs_middlewarelogstash: "{{- $logDir -}}/*.csv"
  aliyun_logs_middlewarelogstash_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
  {{- if .Values.features.auditLog.enabled }}
  aliyun_logs_postgresqlaudit: "{{- $logDir -}}/*.csv"
  aliyun_logs_postgresqlaudit_format: "csv"
  aliyun_logs_postgresqlaudit_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
{{- end }}
{{- end }}

{{- define "pgsql.resources" -}}
resources:
  limits:
    cpu: "{{ .Values.resources.limits.cpu }}"
    memory: "{{ .Values.resources.limits.memory }}"
  requests:
    cpu: "{{ .Values.resources.requests.cpu }}"
    memory: "{{ .Values.resources.requests.memory }}"
{{- end }}