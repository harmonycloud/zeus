{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "pgsql.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "pgsql.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "pgsql.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "pgsql.labels" -}}
helm.sh/chart: {{ include "pgsql.chart" . }}
{{ include "pgsql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "pgsql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "pgsql.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "pgsql.initdb" -}}
initdb:
{{- with .Values.patroni.initdb }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addInitdb" . | nindent 2 -}}
{{- end }}

{{- define "pgsql.addInitdb" -}}
{{- $pg9 := semverCompare "<10.0" .Values.pgsqlVersion }}
{{- if .Values.customVolumes -}}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pgwal" -}}
{{- if $pg9 }}
xlogdir: "{{- get . "mountPath" -}}"
{{- else }}
waldir: "{{- get . "mountPath" -}}"
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "pgsql.userPasswords" -}}
userPasswords:
{{- with .Values.userPasswords }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addStandby" . | nindent 2 -}}
{{- include "pgsql.addHealthcheck" . | nindent 2 -}}
{{- end }}

{{- define "pgsql.addStandby" -}}
{{- if not .Values.userPasswords.standby -}}
standby: Hc@Cloud01
{{- end }}
{{- end }}

{{- define "pgsql.addHealthcheck" -}}
{{- if .Values.users }}
{{- if hasKey .Values.users "healthcheck" }}
    {{- if not .Values.userPasswords.healthcheck -}}
healthcheck: healthcheck@Cloud01
    {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "pgsql.version" -}}
{{- .Values.pgsqlVersion | quote }}
{{- end }}

{{- define "pgsql.customEnvs" -}}
{{- if or .Values.customEnvs ((((.Values.logging).collection).stdout).enabled) ((((.Values.logging).collection).filelog).enabled) .Values.features.auditLog.enabled}}
customEnvs:
{{- with .Values.customEnvs }}
{{- toYaml . | nindent 2 -}}
{{- end }}
  {{- if ((((.Values.logging).collection).stdout).enabled)}}
  aliyun_logs_middlewarestdout: stdout
  aliyun_logs_middlewarestdout_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
{{- $logDir := "/home/postgres/pgdata/pgroot/pg_log" }}
{{- if .Values.customVolumes }}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pglog" }}
{{- $logDir = (get . "mountPath") }}
{{- end }}
{{- end }}
{{- end }}
  {{- if ((((.Values.logging).collection).filelog).enabled)}}
  aliyun_logs_middlewarelogstash: "{{- $logDir -}}/*.csv"
  aliyun_logs_middlewarelogstash_format: "csv"
  aliyun_logs_middlewarelogstash_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
  {{- if .Values.features.auditLog.enabled }}
  aliyun_logs_postgresqlaudit: "{{- $logDir -}}/*.csv"
  aliyun_logs_postgresqlaudit_format: "csv"
  aliyun_logs_postgresqlaudit_tags: "middleware_name={{ include "pgsql.fullname" . }}"
  {{- end}}
  {{- if ne .Values.args.listen_addresses "*" }}
  LISTEN_ADDRESS: "{{ .Values.args.listen_addresses }}"
  {{- end}}
  {{- if index .Values.patroni.initdb "auth-host" }}
  AUTH_HOST: "{{ index .Values.patroni.initdb "auth-host" }}"
  {{- end}}
  {{- if .Values.customEnvs.USE_WALE }}
  {{- if not .Values.customEnvs.WALE_BACKUP_THRESHOLD_MEGABYTES }}
  WALE_BACKUP_THRESHOLD_MEGABYTES: "1073741824"
  {{- end }}
  {{- if not .Values.customEnvs.WALE_BACKUP_THRESHOLD_PERCENTAGE }}
  WALE_BACKUP_THRESHOLD_PERCENTAGE: "1000000"
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "pgsql.resources" -}}
resources:
  limits:
    cpu: "{{ .Values.resources.limits.cpu }}"
    memory: "{{ .Values.resources.limits.memory }}"
  requests:
    cpu: "{{ .Values.resources.requests.cpu }}"
    memory: "{{ .Values.resources.requests.memory }}"
{{- end }}

{{- define "pgsql.exporterTime" -}}
{{- if eq (semverCompare "<13.0" .Values.pgsqlVersion) true }}
{{- "total_time / 1000 as total_time_seconds, min_time / 1000 as min_time_seconds, max_time/ 1000 as max_time_seconds, mean_time / 1000 as mean_time_seconds, stddev_time / 1000 as stddev_time_seconds" }}
{{- else }}
{{- "( total_plan_time + total_exec_time ) / 1000 as total_time_seconds, ( min_plan_time + min_exec_time ) / 1000 as min_time_seconds, ( max_plan_time + max_exec_time ) / 1000 as max_time_seconds, ( mean_plan_time + mean_exec_time ) / 1000 as mean_time_seconds, ( stddev_plan_time + stddev_exec_time )  / 1000 as stddev_time_seconds" }}
{{- end }}
{{- end }}

{{- define "pgsql.archiveCommandMsg" -}}
{{- if .Values.activeActive }}
{{- "if [ $(cat /home/postgres/postgres.yml | grep '{{pg_name}}-' | tail -n 1 | rev | cut -c -1) -lt 2 ];then (test ! -d {{archive_path}} && mkdir -p {{archive_path}}/archive_status ; find {{archive_path}} -type f {{archive_retention_time}} -exec rm -f {} \\;;cp %p {{archive_path}}/%f);else /bin/true; fi" }}
{{- else }}
{{- "(test ! -d {{archive_path}} && mkdir -p {{archive_path}}/archive_status ; find {{archive_path}} -type f {{archive_retention_time}} -exec rm -f {} \\;;cp %p {{archive_path}}/%f)" }}
{{- end }}
{{- end }}

{{- define "pgsql.connectionPooler" }}
connectionPooler:
{{- if .Values.image.pgbouncerImageTag }}
  dockerImage: "{{ .Values.image.repository }}/pgbouncer:{{.Values.image.pgbouncerImageTag}}"
{{- end }}
  numberOfInstances: {{ .Values.connectionPooler.numberOfInstances }}
{{- if .Values.connectionPooler.resources }}
  resources:
    {{- with .Values.connectionPooler.resources }}
    {{- toYaml . | nindent 4 -}}
    {{- end }}
{{- end }}
{{- if .Values.connectionPooler.monitor }}
  monitor:
    {{- with .Values.connectionPooler.monitor }}
    {{- toYaml . | nindent 4 -}}
    {{- end }}
{{- end }}
{{- end }}