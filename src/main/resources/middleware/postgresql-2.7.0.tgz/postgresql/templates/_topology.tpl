
{{/*设置组件label中的key*/}}
{{- define "middleware.key" -}}
cluster-name
{{- end }}

{{/*设置组件label中的name*/}}
{{- define "middleware.name" -}}
{{ include "pgsql.fullname" . }}
{{- end }}


{{- define "middlware.tolerations" }}
{{- with .Values.tolerations }}
tolerations:
{{- toYaml .| nindent 0  }}
{{- end }}
{{- end }}

{{- define "middlware.whenUnsatisfiable" }}
{{- if eq .Values.podAntiAffinity "hard"}}
  whenUnsatisfiable: DoNotSchedule
{{- else if eq .Values.podAntiAffinity "soft"}}
  whenUnsatisfiable: ScheduleAnyway
{{- end }}
{{- end }}

{{- define "middlware.topologySpreadConstraints" }}
{{- if semverCompare ">=1.19-0" .Capabilities.KubeVersion.GitVersion }}
topologySpreadConstraints:
{{- if ne .Values.podAntiAffinityTopologKey "kubernetes.io/hostname"}}
- maxSkew: 1
  topologyKey: {{ .Values.podAntiAffinityTopologKey | default "" }}
  {{- include "middlware.whenUnsatisfiable" . }}
  labelSelector:
      matchLabels:
        {{ include "middleware.key" . }}: {{ include "middleware.name" . }}
{{- end }}
- maxSkew: 1
  topologyKey: "kubernetes.io/hostname"
  {{- include "middlware.whenUnsatisfiable" . }}
  labelSelector:
      matchLabels:
        {{ include "middleware.key" . }}: {{ include "middleware.name" . }}
{{- if .Values.nodeAffinity }}
affinity:
  {{- with .Values.nodeAffinity }}
  nodeAffinity:
  {{- toYaml . | nindent 8 }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "middlware.affinity" }}
{{- if semverCompare "<1.19-0" .Capabilities.KubeVersion.GitVersion }}
affinity:
  {{- if eq .Values.podAntiAffinity "hard"}}
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
    - labelSelector:
        matchExpressions:
        - key: {{ include "middleware.key" . }}
          operator: In
          values:
          - {{ include "middleware.name" . }}
      topologyKey: {{ .Values.podAntiAffinityTopologKey }}
  {{- else if eq .Values.podAntiAffinity "soft"}}
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        topologyKey: {{ .Values.podAntiAffinityTopologKey }}
        labelSelector:
          matchExpressions:
          - key: {{ include "middleware.key" . }}
            operator: In
            values:
            - {{ include "middleware.name" . }}
  {{- end }}
  {{- with .Values.nodeAffinity }}
  nodeAffinity:
  {{- toYaml . | nindent 8 }}
  {{- end }}
  {{- end }}
{{- end }}


{{/*pgsql组件拓扑分布*/}}
{{- define "middlware.topologyDistribution" }}
{{- include "middlware.tolerations" . -}}
{{- include "middlware.topologySpreadConstraints" . -}}
{{- include "middlware.affinity" . -}}
{{- end }}


{{- define "connectionPooler.tolerations" }}
{{- with .Values.connectionPooler.tolerations }}
tolerations:
{{- toYaml .| nindent 0  }}
{{- end }}
{{- end }}

{{- define "connectionPooler.whenUnsatisfiable" }}
{{- if eq .Values.connectionPooler.podAntiAffinity "hard"}}
  whenUnsatisfiable: DoNotSchedule
{{- else if eq .Values.connectionPooler.podAntiAffinity "soft"}}
  whenUnsatisfiable: ScheduleAnyway
{{- end }}
{{- end }}

{{- define "connectionPooler.topologySpreadConstraints" }}
{{- if semverCompare ">=1.19-0" .Capabilities.KubeVersion.GitVersion }}
topologySpreadConstraints:
{{- if ne .Values.connectionPooler.podAntiAffinityTopologKey "kubernetes.io/hostname"}}
- maxSkew: 1
  topologyKey: {{ .Values.connectionPooler.podAntiAffinityTopologKey | default "" }}
  {{- include "connectionPooler.whenUnsatisfiable" . }}
  labelSelector:
      matchLabels:
        connection-pooler: {{ include "middleware.name" . }}-pgbouncer
{{- end }}
- maxSkew: 1
  topologyKey: "kubernetes.io/hostname"
  {{- include "connectionPooler.whenUnsatisfiable" . }}
  labelSelector:
      matchLabels:
        connection-pooler: {{ include "middleware.name" . }}-pgbouncer
{{- if .Values.connectionPooler.nodeAffinity }}
affinity:
  {{- with .Values.connectionPooler.nodeAffinity }}
  nodeAffinity:
  {{- toYaml . | nindent 8 }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "connectionPooler.affinity" }}
{{- if semverCompare "<1.19-0" .Capabilities.KubeVersion.GitVersion }}
affinity:
  {{- if eq .Values.connectionPooler.podAntiAffinity "hard"}}
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
    - labelSelector:
        matchExpressions:
        - key: {{ include "middleware.key" . }}
          operator: In
          values:
          - {{ include "middleware.name" . }}
      topologyKey: {{ .Values.connectionPooler.podAntiAffinityTopologKey }}
  {{- else if eq .Values.connectionPooler.podAntiAffinity "soft"}}
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        topologyKey: {{ .Values.connectionPooler.podAntiAffinityTopologKey }}
        labelSelector:
          matchExpressions:
          - key: {{ include "middleware.key" . }}
            operator: In
            values:
            - {{ include "middleware.name" . }}
  {{- end }}
  {{- with .Values.connectionPooler.nodeAffinity }}
  nodeAffinity:
  {{- toYaml . | nindent 8 }}
  {{- end }}
  {{- end }}
{{- end }}

{{/*connectionPooler组件拓扑分布*/}}
{{- define "connectionPooler.topologyDistribution" }}
{{- include "connectionPooler.tolerations" . -}}
{{- include "connectionPooler.topologySpreadConstraints" . -}}
{{- include "connectionPooler.affinity" . -}}
{{- end }}

