
{{- define "elasticAlert.alertTextArgs" -}}
- "k8s_pod_namespace"
- "middleware_name"
- "k8s_pod"
{{- end -}}

{{- define "elasticAlert.alertTextObject"  -}}
(Namespace: {0}, ServiceName: {1}, Pod: {2})
{{- end -}}

{{- define "elasticAlert.filter" -}}
- term:
    middleware_name.keyword: {{ .releaseName }}
- term:
    k8s_pod_namespace: {{ .releaseNamespace }}

{{- end -}}


{{/* 自定义配置的定义 */}}
{{- define "elasticAlert.customRule" -}}
{{- $customRules := .customRule -}}
{{- $releaseName := .releaseName -}}
{{- $releaseNamespace := .releaseNamespace -}}
{{- $clusterId := .clusterId -}}
{{- $chartName := .chartName -}}
{{- range $name, $rule := $customRules }}
{{ $name }}:
  alertmanager_alertname: {{ $name }}
  index: {{ $rule.index | default "middlewarelogstash*" }}
  timeframe:
    minutes: {{ $rule.interval | default "5" }}
  {{- if eq $rule.type "frequency" }}
  # frequency
  type: frequency
  num_events: {{ $rule.threshold | default "10" }}
  filter:
    {{ $d := dict "releaseName" $releaseName "releaseNamespace" $releaseNamespace }}
    {{ include "elasticAlert.filter" $d | nindent 4 }}
    {{- if $rule.filter }}
    {{- toYaml $rule.filter | nindent 4 }}
    {{- end }}
  {{- else if eq $rule.type "blacklist" }}

  # blacklist
  type: blacklist
  include: ["{{ $rule.compare_key }}"]
  compare_key: {{ $rule.compare_key }}
  blacklist:
    {{- toYaml $rule.blacklist | nindent 4 }}
  filter:
    {{ include "elasticAlert.filter" $ | nindent 4 }}
    {{- if $rule.filter }}
    {{- toYaml $rule.filter | nindent 4 }}
    {{- end }}

  {{- else }}
  # any
  type: any
  filter:
    {{ include "elasticAlert.filter" $ | nindent 4 }}
    {{- if $rule.filter }}
    {{- toYaml $rule.filter | nindent 4 }}
    {{- end }}
  {{- end }}
  
  # alertmanager_annotations
  alertmanager_annotations:
    severity: {{ $rule.alertLevel | default "warning" }}
    silence: "{{ $rule.silence | default 10 }}"
  
  # alertTextArgs
  alert_text_args:
    {{ include "elasticAlert.alertTextArgs" $ | nindent 4 }}
    {{- if $rule.alertTextArgs }}
    {{- toYaml $rule.alertTextArgs | nindent 4 }}
    {{- end }}
    
  alert_text: "{{ $rule.alertText | default $name }} {{ include "elasticAlert.alertTextObject" $ }}"
  alert:
  - alertmanager
  alert_text_type: alert_text_only
  alertmanager_hosts:
    -  "http://alertmanager-elastalert.monitoring:9093"

  alertmanager_labels:
    source: {{ $name }}
    alert_name: {{ $name }}
    clusterId: {{ $clusterId | default "" }}
    middleware: {{ $chartName }}
    
  alertmanager_fields:
    namespace: k8s_pod_namespace
    middleware_name: middleware_name
    pod: k8s_pod

{{- end }}
{{- end -}}






{{/* 将默认配置与 values.yaml 中的配置进行合并 */}}
{{- define "elasticAlert.merge" -}}
{{- $elasticAlertValues := .rule }}
{{- $defaultConfig := include "elasticAlert" . | fromYaml -}}
{{- $valuesConfig := $elasticAlertValues | default dict -}}
{{- $result := dict -}}

{{- range $ruleName, $defaultRule := $defaultConfig -}}
  {{- $userRule := dict -}}
  {{- if hasKey $valuesConfig $ruleName -}}
    {{- $userRule = index $valuesConfig $ruleName -}}
  {{- end -}}
  {{- $mergedRule := deepCopy $defaultRule -}}
  {{- range $key, $value := $userRule -}}
    {{- $_ := set $mergedRule $key $value -}}
  {{- end -}}
  {{- $_ := set $result $ruleName $mergedRule -}}
{{- end -}}

{{- range $ruleName, $userRule := $valuesConfig -}}
  {{- if not (hasKey $defaultConfig $ruleName) -}}
    {{- $_ := set $result $ruleName $userRule -}}
  {{- end -}}
{{- end -}}

{{- toYaml $result -}}
{{- end -}}

{{/* 最终的配置 */}}
{{ define "elasticAlertConfig" }}
{{- $releaseName := .releaseName }}
{{- $releaseNamespace := .releaseNamespace }}
{{- $rule := .rule }}
{{- $customRule := .customRule }}
{{- $clusterId := .clusterId }}
{{- $chartName := .chartName }}
{{/* 直接使用customRule生成配置 */}}
{{- $d := dict "customRule"  $customRule  "releaseName" $releaseName "releaseNamespace" $releaseNamespace "clusterId" $clusterId "chartName" $chartName }}

{{- $customElasticAlert := include "elasticAlert.customRule" $d | fromYaml }}
{{- range $name, $rule := $customElasticAlert}}
  {{ $releaseNamespace }}_{{ $releaseName }}_custom_elasticAlert_{{ $name }}.yaml: |
    {{- range $key, $value := $rule }}
    {{- if eq $key "alert_text" }}
    {{ $key }}: "{{ $value }}"
    {{- else }}
    {{- $valueType := kindOf $value }}
    {{- if or (eq $valueType "map") (eq $valueType "slice") }}
    {{ $key }}:
{{ $value | toYaml | indent 6 }}
    {{- else }}
    {{ $key }}: {{ $value | toYaml | trim }}
    {{- end }}
    {{- end }}
    {{- end }}
{{- end }}



{{/* 使用 elasticAlert.merge 模板合并默认配置和 values.yaml 中的配置 */}}
{{- $d := dict "rule"  $rule  "releaseName" $releaseName "releaseNamespace" $releaseNamespace "clusterId" $clusterId "chartName" $chartName }}
{{- $defaultElasticAlert := include "elasticAlert.merge" $d | fromYaml }}
{{/* 再将合并后的defaultElasticAlert， 作为customRule传入elasticAlert.customRule */}}
{{- $d := dict "customRule"  $defaultElasticAlert "releaseName" $releaseName "releaseNamespace" $releaseNamespace "clusterId" $clusterId "chartName" $chartName }}
{{- $elasticAlert :=  include "elasticAlert.customRule" $d | fromYaml}}
{{- range $name, $rule := $elasticAlert}}
  {{ $releaseNamespace  }}_{{ $releaseName }}_elasticAlert_{{ $name }}.yaml: |
    {{- range $key, $value := $rule }}
    {{- if eq $key "alert_text" }}
    {{ $key }}: "{{ $value }}"
    {{- else }}
    {{- $valueType := kindOf $value }}
    {{- if or (eq $valueType "map") (eq $valueType "slice") }}
    {{ $key }}:
{{ $value | toYaml | indent 6 }}
    {{- else }}
    {{ $key }}: {{ $value | toYaml | trim }}
    {{- end }}
    {{- end }}
    {{- end }}
{{- end }}

{{- end }}
