{{- define "pgsql.cal.memory" -}}
    {{- $memory := regexFind "[0-9]*[.]*[0-9]*" .Values.resources.limits.memory }}
    {{- $memoryB := 0 }}

    {{- if contains "." $memory }}
        {{- $memoryLs := regexSplit "\\." ($memory | toString) -1 }}
        {{- $memoryInt := index $memoryLs 0 }}
        {{- $memoryDecimal := index $memoryLs 1 }}
        {{- $memoryDecimalLen := len $memoryDecimal }}
        {{- $memoryDecimalDigit := 1 }}
        {{- range untilStep 0 $memoryDecimalLen 1 }}
        {{- $memoryDecimalDigit = mul $memoryDecimalDigit 10 }}
    {{- end }}
    {{- if contains "GI" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = add (mul ($memoryInt | int) 1024 1024 1024) (div (mul ($memoryDecimal | int) 1024 1024 1024) $memoryDecimalDigit) }}
    {{- else if contains "G" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = add (mul ($memoryInt | int) 1000 1000 1000) (div (mul ($memoryDecimal | int) 1000 1000 1000) $memoryDecimalDigit) }}
    {{- else if contains "MI" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = add (mul ($memoryInt | int) 1024 1024) (div (mul ($memoryDecimal | int) 1024 1024) $memoryDecimalDigit) }}
    {{- else if contains "M" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = add (mul ($memoryInt | int) 1000 1000) (div (mul ($memoryDecimal | int) 1000 1000) $memoryDecimalDigit) }}
    {{- end }}
    {{- else }}
    {{- if contains "GI" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = mul $memory 1024 1024 1024 }}
    {{- else if contains "G" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = mul $memory 1000 1000 1000 }}
    {{- else if contains "MI" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = mul $memory 1024 1024 }}
    {{- else if contains "M" (upper .Values.resources.limits.memory) }}
        {{- $memoryB = mul $memory 1000 1000 }}
    {{- end }}
    {{- end }}

    {{- printf "%d" $memoryB }}
{{- end }}

{{- define "pgsql.cal.sharedBuffers" -}}
    {{- $sharedBuffers := 0 }}

    {{- if .Values.args.shared_buffers }}
        {{- if contains "GI" (upper .Values.args.shared_buffers) }}
            {{- $sharedBuffers = mul (regexFind "[0-9]*" .Values.args.shared_buffers) 1024 }}
        {{- else if contains "G" (upper .Values.args.shared_buffers) }}
            {{- $sharedBuffers = mul (regexFind "[0-9]*" .Values.args.shared_buffers) 1000 }}
        {{- else }}
            {{- $sharedBuffers = regexFind "[0-9]*" .Values.args.shared_buffers }}
        {{- end }}
    {{- end }}

    {{- if not .Values.args.shared_buffers -}}
        {{- $sharedBuffers = div (div (div (include "pgsql.cal.memory" .) 4) 1024) 1024 }}
    {{- end }}

    {{- printf "%d" $sharedBuffers }}
{{- end }}

{{- define "pgsql.cal.workMem" -}}
    {{- $workMem := 4 }}

    {{- if .Values.args.work_mem }}
        {{- if contains "GI" (upper .Values.args.work_mem) }}
            {{- $workMem = mul (regexFind "[0-9]*" .Values.args.work_mem) 1024 | int }}
        {{- else if contains "G" (upper .Values.args.work_mem) }}
            {{- $workMem = mul (regexFind "[0-9]*" .Values.args.work_mem) 1000 | int }}
        {{- else }}
            {{- $workMem = regexFind "[0-9]*" .Values.args.work_mem | int }}
        {{- end }}
    {{- end }}

    {{- printf "%d" $workMem }}
{{- end }}

{{- define "pgsql.cal.maxConnections" -}}
    {{- $memoryB := (include "pgsql.cal.memory" .) | int }}
    {{- $sharedBuffers := (include "pgsql.cal.sharedBuffers" .) | int }}
    {{- $workMem := (include "pgsql.cal.workMem" .) | int }}
    {{- $maxConn := max (div (div (sub (div (div $memoryB 1024) 1024) $sharedBuffers) $workMem) 2) 170 }}

    {{- printf "%d" $maxConn }}
{{- end }}

{{- define "pgsql.maxConnections" -}}
    {{- $pgMaxConnections := (include "pgsql.cal.maxConnections" .) | int }}
    {{- if .Values.args.max_connections -}}
    {{- $pgMaxConnections = .Values.args.max_connections | int }}
    {{- end }}

    {{- printf "%d" $pgMaxConnections }}
{{- end }}


{{- define "pgsql.parameters" -}}
parameters:
{{- with .Values.args }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addParameters" . | nindent 2 -}}
{{- with .Values.additionArgs }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- end }}

{{- define "pgsql.addParameters" -}}
{{- $cpu := regexFind "[0-9]*[.]*[0-9]*" (toString .Values.resources.limits.cpu) }}

{{- if contains "m" (lower (toString .Values.resources.limits.cpu)) }}
{{- $cpuInt := ($cpu | int) }}
{{- if contains "." $cpu }}
{{- $cpuLs := regexSplit "\\." ($cpu | toString) -1 }}
{{- $cpuInt = index $cpuLs 0 }}
{{- $cpuDecimal := index $cpuLs 1 }}
{{- if gt ($cpuDecimal | int) 0 }}
{{- $cpuInt = add $cpuInt 1 }}
{{- end }}
{{- end }}

{{- if lt $cpuInt 1000  }}
{{- $cpu = 1 }}
{{- else }}
{{- if gt (mod $cpuInt 1000) 0  }}
{{- $cpu = printf "%d%s%s" (div $cpuInt 1000) "." ((mod $cpuInt 1000)| toString) }}
{{- else }}
{{- $cpu = (div $cpuInt 1000) | toString }}
{{- end }}
{{- end }}
{{- end }}

{{/*
autovacuum
autovacuum_work_mem——{GREATEST(DBInstanceMemory/65536, 131072)},单位为KB
autovacuum_max_workers——{LEAST(GREATEST(DBInstanceMemory/17179869184, 3), 10)}
*/}}
{{- if (toString .Values.args.autovacuum | eq "on") }}
{{- if not .Values.args.autovacuum_work_mem -}}
autovacuum_work_mem: {{ div (max (div (include "pgsql.cal.memory" .) 65536) 131072) 1024 -}}MB
{{ end }}
{{- if not .Values.args.autovacuum_max_workers -}}
autovacuum_max_workers: "{{- min (max (div (include "pgsql.cal.memory" .) 17179869184) 3) 10 -}}"
{{- end }}
{{- end }}

{{/*
effective_cache_size——{DBInstanceMemory/16384},单位为8KB
*/}}
{{- if not .Values.args.effective_cache_size -}}
effective_cache_size: "{{- div (include "pgsql.cal.memory" .) 16384 -}}"
{{- end }}

{{/*
maintenance_work_mem——{LEAST(DBInstanceMemory/16384, 4194304)},单位为KB
*/}}
{{- if not .Values.args.maintenance_work_mem -}}
maintenance_work_mem: "{{- min (div (include "pgsql.cal.memory" .) 16384) 4194304 -}}"
{{- end }}

{{/*
max_parallel_workers_per_gather——{GREATEST(DBInstanceCPU/2, 2)}
*/}}
{{- if not .Values.args.max_parallel_workers_per_gather -}}
{{- $cpuInt := ($cpu | int) }}
{{- if contains "." ($cpu | toString) }}
{{- $cpuLs := regexSplit "\\." ($cpu | toString) -1 }}
{{- $cpuInt = index $cpuLs 0 }}
{{- $cpuDecimal := index $cpuLs 1 }}
{{- if gt ($cpuDecimal | int) 0 }}
{{- $cpuInt = add ($cpuInt | int) 1 }}
{{- end }}
{{- end }}
{{- $cpuInt = ($cpuInt | int) }}
{{- if le $cpuInt 4 -}}
max_parallel_workers_per_gather: "2"
{{- else }}
{{- if gt (mod $cpuInt 2) 0 -}}
max_parallel_workers_per_gather: "{{- add (max (div $cpuInt 2) 2) 1 -}}"
{{- else }}
max_parallel_workers_per_gather: "{{- max (div $cpuInt 2) 2 -}}"
{{- end }}
{{- end }}
{{- end }}


{{/*
max_wal_size——{{LEAST(GREATEST(DBInstanceMemory/2097152, 2048), 16384)}，单位为MB
*/}}
{{- if not .Values.args.max_wal_size -}}
max_wal_size: "{{- min (max (div (include "pgsql.cal.memory" .) 2097152) 2048) 16384 -}}"
{{- end }}


{{/*
max_parallel_maintenance_workers——{GREATEST(DBInstanceCPU/2, 2)}
*/}}
{{- if not .Values.args.max_parallel_maintenance_workers -}}
{{- $cpuInt := ($cpu | int) }}
{{- if contains "." ($cpu | toString) }}
{{- $cpuLs := regexSplit "\\." ($cpu | toString) -1 }}
{{- $cpuInt = index $cpuLs 0 }}
{{- $cpuDecimal := index $cpuLs 1 }}
{{- if gt ($cpuDecimal | int) 0 }}
{{- $cpuInt = add ($cpuInt | int) 1 }}
{{- end }}
{{- end }}
{{- $cpuInt = ($cpuInt | int) }}
{{- if le $cpuInt 4 -}}
max_parallel_maintenance_workers: "2"
{{- else }}
{{- if gt (mod $cpuInt 2) 0 -}}
max_parallel_maintenance_workers: "{{- add (max (div $cpuInt 2) 2) 1 -}}"
{{- else }}
max_parallel_maintenance_workers: "{{- max (div $cpuInt 2) 2 -}}"
{{- end }}
{{- end }}
{{- end }}

{{/*
max_parallel_workers——{GREATEST(DBInstanceCPU*3/4, 2)}
*/}}
{{- if not .Values.args.max_parallel_workers -}}
max_parallel_workers: "{{- max (div (mul $cpu 3) 4) 2 -}}"
{{- end }}


{{/*
shared_buffers——{DBInstanceMemory/4}，单位为GB
*/}}
{{- if not .Values.args.shared_buffers -}}
shared_buffers: "{{- max (include "pgsql.cal.sharedBuffers" .) 128 -}}MB"
{{- end }}


{{/*
wal_buffers——{LEAST(GREATEST(DBInstanceMemory/2097152, 2048), 16384)}，单位为8KB
*/}}
{{- if not .Values.args.wal_buffers -}}
wal_buffers: "{{- min (max (div (include "pgsql.cal.memory" .) 2097152) 2048) 16384 -}}"
{{- end }}


{{/*
max_connections——{LEAST(GREATEST((DBInstanceMemory-shared_buffers)/work_mem/2, 170)}
*/}}
{{- if not .Values.args.max_connections -}}
max_connections: "{{- (include "pgsql.maxConnections" .) -}}"
{{- end }}


{{- if not .Values.args.log_directory -}}
{{- if .Values.customVolumes }}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pglog" }}
log_directory: "{{- get . "mountPath" -}}"
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- if not .Values.args.bg_mon_port -}}
{{- with .Values.customEnvs }}
{{- if get . "BGMONPORT" }}
bg_mon.port: "{{- get . "BGMONPORT" -}}"
{{- end }}
{{- end }}
{{- end }}

{{- if not .Values.args.port -}}
{{- with .Values.customEnvs }}
{{- if get . "PGPORT" }}
port: "{{- get . "PGPORT" -}}"
{{- end }}
{{- end }}
{{- end }}

{{- if .Values.activeActive }}
archive_mode: "always"
{{- else }}
archive_mode: "on"
{{- end }}

{{- if .Values.customVolumes }}
{{- range .Values.customVolumes }}
{{- if eq (get . "name") "pgarch" }}
archive_command: "ulimit -c 0 && cp %p {{ get . "mountPath" -}}/%f;chmod 604 {{ get . "mountPath" -}}/%f"
{{- end }}
{{- end }}
{{- end }}

{{- end }}

{{- define "pgsql.connectionPoolerParameters" -}}
parameters:
{{- with .Values.connectionPooler.args }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- include "pgsql.addConnectionPoolerParameters" . | nindent 2 -}}
{{- with .Values.connectionPooler.additionArgs }}
{{- toYaml . | nindent 2 -}}
{{- end }}
{{- end }}

{{/*
max_db_connections——{PGMaxConnections/PgbouncerNumberOfInstances}
*/}}
{{- define "pgsql.addConnectionPoolerParameters" -}}
{{- if not .Values.connectionPooler.args.max_db_connections -}}
{{- $maxDBConnections := div (include "pgsql.maxConnections" .) .Values.connectionPooler.numberOfInstances }}
max_db_connections: "{{- $maxDBConnections -}}"
{{- end }}

{{/*
default_pool_size——{PGMaxConnections/PgbouncerNumberOfInstances/2}
*/}}
{{- if not .Values.connectionPooler.args.default_pool_size -}}
{{- $defaultPoolSize := div (div (include "pgsql.maxConnections" .) .Values.connectionPooler.numberOfInstances) 2 }}
default_pool_size: "{{- $defaultPoolSize -}}"
{{- end }}

{{/*
min_pool_size——{PGMaxConnections/PgbouncerNumberOfInstances/2/2}
*/}}
{{- if not .Values.connectionPooler.args.min_pool_size -}}
{{- $minPoolSize := div (div (div (include "pgsql.maxConnections" .) .Values.connectionPooler.numberOfInstances) 2) 2 }}
min_pool_size: "{{- $minPoolSize -}}"
{{- end }}

{{/*
reserve_pool_size——{PGMaxConnections/PgbouncerNumberOfInstances/2/2}
*/}}
{{- if not .Values.connectionPooler.args.reserve_pool_size -}}
{{- $reservePoolSize := div (div (div (include "pgsql.maxConnections" .) .Values.connectionPooler.numberOfInstances) 2) 2 }}
reserve_pool_size: "{{- $reservePoolSize -}}"
{{- end }}

{{- end }}